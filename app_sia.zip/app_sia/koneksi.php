<?php
2. $host = "localhost";
3. $user = "root";
4. $pass = "";
5. $db = "db_app_sia";
6. $koneksi = new mysqli($host, $user, $pass, $db);
7. ?>