<p class="alert alert-info">
Selamat datang di aplikasi<strong>Sistem Informasi Akuntasi</strong>,aplikasi ini dirancang untuk memudahkan manajemen transaksi penjualan
</p>